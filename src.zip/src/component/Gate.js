function Gate(props){
  return <> {props.isOpen == true ? 'closed' : 'open'}


  
  </>
   
   

}
export default Gate;