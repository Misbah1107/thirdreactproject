import ReactDOM from 'react-dom';

function MediaCard(props){
 
 return(  <> 
 <h1>{props.title}</h1>
  <p>{props.body}</p>
  <img src={props.pic} />
  
   </>)
}
export default MediaCard;
ReactDOM.render( <MediaCard />,  document.getElementById('root'))