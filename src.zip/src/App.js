import logo from './logo.svg';
import './App.css';
import MediaCard from './component/MediaCard';
import imageURL from "./component/img/Programming-code-on-computer.jpg"
import Gate from './component/Gate';

function App() {
  return (
    <div className="App">
     <MediaCard title = "Biodata" body =  "My name is Misbah. I am learning Mobile and Web Development" pic = {imageURL}   />
     <Gate isOpen = 'open' />
    </div>
  );
}

export default App;
